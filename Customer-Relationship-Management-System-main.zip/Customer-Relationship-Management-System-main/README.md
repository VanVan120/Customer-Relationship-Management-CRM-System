# Customer-Relationship-Management-System
Built a localhost database using HTML, CSS, Javascript, PHP, and SQL for maintaining customer relationships with clients
